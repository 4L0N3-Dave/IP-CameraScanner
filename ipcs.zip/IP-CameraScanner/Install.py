import os,re
import time

ir = "\033[0;101m"
r = "\033[0m"

print("Type [Y] to see recommended commands:")

user = input("Enter: ").lower()
print("")
install = "pip2 install requests && pip install --upgrade pip && ls && python2 ipcs.py"

if user =="y":
	
	print("Credit:",ir,"Dave Chiva",r)
	print("")
	print("• "+"\033[1;34m""Just Copy the one line command below ""\033[0m"+"•")
	print("========================================")
	print("\033[0;32m",install)
	print("\033[0m""========================================")
	print("\033[0m""• ""\033[1;34m""Paste it after you close this program and hit ENTER...""\033[0m""\033[0m"" •")
else:
	os.sys.exit()
print("")
print("Type [e/exit] to close...")
user2 = input("Enter: ").lower()

if user2 == "exit" or user2 =="e":
	
	print("\033[0;31m""Exiting....")
	time.sleep(2.5)
	print("\033[0;32m""Done")
	print("\033[0m")
	os.sys.exit()
else:
	os.sys.exit
