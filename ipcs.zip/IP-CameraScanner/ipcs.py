#

import LIST
from LIST.ph import *
from LIST.au import*
from LIST.vn import*
from LIST.us import*
from LIST.kr import*
from LIST.jp import*
from LIST.th import*
from LIST.tw import*
import requests,re,os

b="\033[0;34m"
g="\033[1;32m"
w="\033[1;37m"
r="\033[1;31m"
y="\033[1;33m"
cyan = "\033[0;36m"
lgray = "\033[0;37m"
dgray = "\033[1;30m"
ir = "\033[0;101m"
reset = "\033[0m"



def main():
    os.system('clear')
    print("{}        ____ ").format(b)
    print("   _[]_/____\__n_ ")
    print("  |_____.--.__()_|")
    print("  |I   //# \\\    |")
    print("{}  |P   \\\__//    | ").format(cyan)
    print("  |CS   '--'     | ").format(b)
    print("{}  '--------------'----------{}------------------.  ").format(b,b)
    print("{}  | {}Author : {}Dave Chiva {} | {}PHILI{}PP{}INES | ").format(r,w,g,r,b,ir,b,r)
    print("{}  | {}CODENAME : {}4L0N3 {} | {}+639652093493{} |").format(r,w,cyan,w,g,r)
    print("{}  '------------------------------------{}-------'  ").format(b,b)
    print ("  {}[ 1 ] {}Philippines").format(r,b)
    print ("  {}[ 2 ] {}Australia").format(r,b)
    print("  {}[ 3 ] {}Vietname").format(r,b)
    print("  {}[ 4 ] {}Unitedstates").format(r,b)
    print ("  {}[ 5 ] {}Korea").format(r,b)
    print ("  {}[ 6 ] {}Japan").format(r,b)
    print ("  {}[ 7 ] {}Thailand").format(r,b)
    print ("  {}[ 8 ] {}Taiwan").format(r,b)
    print ("  {}[ 00] {}Exit").format(r,b)
    print ""
    select = input("\033[1;31m[ \033[1;37mChoose@Number \033[1;31m]\033[1;37m> ")
    filtering(select)

def filtering(pilih):
    if pilih == 1:
        Philippines()
    elif pilih == 2:
        Australia()
    elif pilih == 3:
        Vietnam()
    elif pilih == 4:
        Unitedstates()
    elif pilih == 5:
        Korea()
    elif pilih == 6:
        Japan()
    elif pilih == 7:
        Thailand()
    elif pilih == 8:
        Taiwan()
    elif pilih == 0:
        print (r+"Exiting ..."+w)
        os.sys.exit()
    else:
        print (r+"Exiting ..."+w)
        os.sys.exit()

if __name__ == '__main__':
    main()
